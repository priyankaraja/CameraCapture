#include "FlyCapture2.h"
#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <vector>

using namespace FlyCapture2;

// Only used for standard
//#define _VIDEOMODE   VIDEOMODE_640x480Y8

enum AviType
{
	UNCOMPRESSED,
	MJPG,
	H264
};

// Print the information about the library
void PrintBuildInfo()
{
	FC2Version fc2Version;
	Utilities::GetLibraryVersion(&fc2Version);

	std::ostringstream version;
	version << "Library version: " << fc2Version.major << "." << fc2Version.minor << "." << fc2Version.type << "." << fc2Version.build;
	std::cout << version.str() << std::endl;

	std::ostringstream timeStamp;
	timeStamp << "Application build date: " << __DATE__ << " " << __TIME__;
	std::cout << timeStamp.str() << std::endl << std::endl;
}

void PrintError(Error error)
{
	error.PrintErrorTrace();
}

// Method that converts images to video
void SaveAviHelper(
	AviType aviType,
	std::vector<Image>& vecImages,
	std::string aviFileName,
	float frameRate)
{
	Error error;
	AVIRecorder aviRecorder;

	// Open the AVI file handler for appending images.
	switch (aviType)
	{
  	  case UNCOMPRESSED:
	  {
		AVIOption option;
		option.frameRate = frameRate;
		error = aviRecorder.AVIOpen(aviFileName.c_str(), &option);
	  }
	  break;
	  case MJPG:
	  {
		MJPGOption option;
		option.frameRate = frameRate;
		option.quality = 75;
		error = aviRecorder.AVIOpen(aviFileName.c_str(), &option);
	  }
	  break;
	} // end of switch

	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return;
	}

	std::cout << std::endl;
	std::cout << "Appending " << vecImages.size() << " images to AVI file: " << aviFileName.c_str() << std::endl;
	for (int imageCnt = 0; imageCnt < vecImages.size(); imageCnt++)
	{
		// Append the image to AVI file
		error = aviRecorder.AVIAppend(&vecImages[imageCnt]);
		if (error != PGRERROR_OK)
		{
			PrintError(error);
			continue;
		}
		std::cout << "Appended image " << imageCnt << "..." << std::endl;
	}

	// Close the AVI file
	error = aviRecorder.AVIClose();
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return;
	}
}

// Capture Video using the given arguments
int RunCamera(PGRGuid guid, double frameRate, int numFrames, int exposureValue, float gainValue) {
	const int k_numImages = numFrames;

	Error error;
	Camera camera;

	// Connect to the camera
	error = camera.Connect(&guid);
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return -1;
	}

	// Get the camera information
	CameraInfo camInfo;
	error = camera.GetCameraInfo(&camInfo);
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return -1;
	}

	// Set the exposure value in the camera
	Property exposure(PropertyType::AUTO_EXPOSURE);
	exposure.autoManualMode = false;
	exposure.onOff = true;
	exposure.absControl = false;
	exposure.valueA = exposureValue;
	camera.SetProperty(&exposure);

	// Set the gain value in the camera
	Property gain(PropertyType::GAIN);
	gain.absControl = true;
	gain.onePush = false;
	gain.onOff = true;
	gain.autoManualMode = true;
	gain.absValue = gainValue;
	camera.SetProperty(&gain);

	// Check if the camera supports the FRAME_RATE property
	std::cout << "Detecting Frame Rate from camera... " << std::endl;
	PropertyInfo propInfo;
	propInfo.type = FRAME_RATE;
	error = camera.GetPropertyInfo(&propInfo);
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return -1;
	}

	float frameRateToUse = (float)frameRate;
	if (propInfo.present == true)
	{
		// Get the frame rate
		Property prop;
		prop.type = FRAME_RATE;
		error = camera.GetProperty(&prop);
		if (error != PGRERROR_OK)
		{
			PrintError(error);
		}
		else
		{
			if (frameRateToUse < 0) {
				frameRateToUse = prop.absValue;
			}
			// Note that the actual recording frame rate may be slower,
			// depending on the bus speed and disk writing speed.
			/*if (frameRateToUse > prop.absValue) {
				// set camera frameRate
				VideoMode _VIDEOMODE = VIDEOMODE_640x480Y8;
				FrameRate _FRAMERATE = FRAMERATE_7_5;
				if (frameRateToUse < FRAMERATE_15)
				{
					_FRAMERATE = FRAMERATE_15;
				} 
				else if (frameRateToUse < FRAMERATE_30)
				{
					_FRAMERATE = FRAMERATE_30;
				}
				else if (frameRateToUse < FRAMERATE_60)
				{
					_FRAMERATE = FRAMERATE_60;
				}
				else if (frameRateToUse < FRAMERATE_120)
				{
					_FRAMERATE = FRAMERATE_120;
				}
				else if (frameRateToUse < FRAMERATE_240)
				{
					_FRAMERATE = FRAMERATE_240;
				}

				bool isSupported = false;

				VideoMode vmode;
				FrameRate frate;

				error = cam.GetVideoModeAndFrameRate(&vmode, &frate);
				if (error != PGRERROR_OK)
				{
					PrintError(error);
					return -1;
				}

				std::cout << "Current mode values " << vmode << " " << frate << std::endl;

				Format7ImageSettings f7info;
				unsigned int psize;
				float percent;
				error = cam.GetFormat7Configuration(&f7info, &psize, &percent);
				if (error != PGRERROR_OK)
				{
					PrintError(error);
					return -1;
				}

				std::cout << f7info.mode << " " << f7info.pixelFormat  << " " << f7info.height << " " <<f7info.width <<std::endl;
				//check the video mode and framerate
			    error = cam.GetVideoModeAndFrameRateInfo(
						_VIDEOMODE,
						_FRAMERATE,
						&isSupported);
				if (error != PGRERROR_OK)
				{
					PrintError(error);
					return -1;
				}

				if (isSupported == false)
				{
					// Videomode and framerate are not valid for this camera
					std::cout << "The video mode and frame rate is not supported on this camera" << std::endl;
					return -1;
				}

				// Set the VideoMode and FrameRate
				error = cam.SetVideoModeAndFrameRate(_VIDEOMODE, _FRAMERATE);
				if (error != PGRERROR_OK)
				{
					PrintError(error);
					return -1;
				}

			}*/
		}
	}

	// Start capturing images
	std::cout << "Starting capture of images." << std::endl;
	error = camera.StartCapture();
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return -1;
	}

	std::vector<Image> vecImages;
	vecImages.resize(k_numImages);

	// Grab images
	Image rawImage;
	for (int imageCnt = 0; imageCnt < k_numImages; imageCnt++)
	{
		error = camera.RetrieveBuffer(&rawImage);
		if (error != PGRERROR_OK)
		{
			std::cout << "Error grabbing image " << imageCnt << std::endl;
			continue;
		}
		else
		{
			std::cout << "Grabbed image " << imageCnt << std::endl;
		}

		vecImages[imageCnt].DeepCopy(&rawImage);
	}

	// Stop capturing images
	std::cout << "Stopping capture of images." << std::endl;
	error = camera.StopCapture();
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return -1;
	}

	std::cout << "Using frame rate of " << std::fixed << std::setprecision(1) << frameRateToUse << std::endl;

	// Save the images without any compression
	std::ostringstream aviFileName;
	aviFileName << "SaveImageToAviEx-Uncompressed-" << std::fixed << std::setprecision(1) << frameRateToUse << "_" << exposureValue << "_" << std::fixed << std::setprecision(1) << gainValue;
	SaveAviHelper(UNCOMPRESSED, vecImages, aviFileName.str().c_str(), frameRateToUse);
	aviFileName.str("");
	aviFileName.clear();

	// Save the images with Mjpg compression
	aviFileName << "SaveImageToAviEx-Mjpg-" << std::fixed << std::setprecision(1) << frameRateToUse << "_" << exposureValue << "_" << std::fixed << std::setprecision(1) << gainValue;
	SaveAviHelper(MJPG, vecImages, aviFileName.str().c_str(), frameRateToUse);
	aviFileName.str("");
	aviFileName.clear();

	// Disconnect the video camera
	error = camera.Disconnect();
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return -1;
	}
	return 0;
}

int main(int argc, char** argv) {
	
	/*
	  The main expects 4 arguments. All arguments MUST be passed.
	  Camera_Capture.exe <Frame Rate[1 - 150]> <Number of Frames> <Exposure Value> <Gain Value>
	  Current implementation does not support Frame Rate. Defaults to 40 FPS.
	  Number of Frames determines the length of the video.
	  Exposure Value is used to set the camera exposure
	  Gain Value is used to set the camera gain
	*/
	if (argc != 5) {
		std::cout << "Please enter a frame rate between [1 - 150], number of frames, exposure value, gain value" << std::endl;
		return -1;
	}

	double frameRate = atof(argv[1]);
	int numFrames = atoi(argv[2]);
	int exposure = atoi(argv[3]);
	float gain = (float)atof(argv[4]);
	std::cout << "Entered frame rate: " << std::fixed << std::setprecision(1) << frameRate << std::endl;
	std::cout << "Entered number of frames: " <<  numFrames << std::endl;
	std::cout << "Entered exposure: " << exposure << std::endl;
	std::cout << "Entered gain: " << gain << std::endl;

	PrintBuildInfo();

	Error error;
	errno_t err;
	// The current directory is used to save the pictures and the video.
	// Check for write permissions in the current directory.
	FILE* tempFile;
	err = fopen_s(&tempFile, "test.txt", "w+");
	if (err != 0) {
		std::cout << "Failed to create file in current folder.  Please check permissions." << std::endl;
		return -1;
	}
	fclose(tempFile);

	BusManager busManager;
	unsigned int numCameras;
	// get the number of cameras
	error = busManager.GetNumOfCameras(&numCameras);
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return -1;
	}

	if (numCameras < 1)
	{
		std::cout << "No camera detected." << std::endl;
		return -1;
	}
	else
	{
		std::cout << "Number of cameras detected: " << numCameras << std::endl;
	}

	PGRGuid guid;
    // Get the camera index
	error = busManager.GetCameraFromIndex(0, &guid);
	if (error != PGRERROR_OK)
	{
		PrintError(error);
		return -1;
	}

	std::cout << "Capturing Video. " << std::endl;
	RunCamera(guid, frameRate, numFrames, exposure, gain);

	std::cout << "Done! Press Enter to exit..." << std::endl;
	std::cin.ignore();

	return 0;
}

